# AIcode 部署包

- `docker-compose.yml`（Linux/NAS，host 网络）+ `docker-compose.windows.yml`（Windows/Docker Desktop，bridge + 端口映射）
   + `.env.example`：先 `cp .env.example .env` 再填 `DEEPSEEK_API_KEY`
- `gateway/`：网关（鉴权/配对/手机控制/更新通道）
- `preflight.sh`：部署前体检（只读）——建好 `.env` 后跑 `bash preflight.sh`，有 FAIL 先修
- 启动：Linux `docker compose up -d --build`；Windows `docker compose -f docker-compose.windows.yml up -d --build`
- 配对码：`docker compose exec -T aicode cat /data/pair-code`（一次性，交付前重新取）
- 交付主人：优先给一段 `http://<IP>:<网关端口>|<密钥>`（`cat /data/secret` 取），App 连接页「从剪贴板导入连接」直接粘
- 详细步骤见站点上的 deploy-for-ai.md
