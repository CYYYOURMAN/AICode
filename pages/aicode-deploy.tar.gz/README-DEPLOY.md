# AIcode 部署包

- `docker-compose.yml` + `.env.example`：cp .env.example .env 后填 DEEPSEEK_API_KEY
- `gateway/`：网关（鉴权/配对/手机控制/更新通道）
- 启动：docker compose up -d --build
- 配对码：docker compose exec aicode cat /data/pair-code
- 详细步骤见站点上的 deploy-for-ai.md
