# AIcode 部署包

- `docker-compose.yml` + `.env.example`：cp .env.example .env 后填 DEEPSEEK_API_KEY
- `gateway/`：网关（鉴权/配对/手机控制/更新通道）
- `preflight.sh`：部署前体检（只读）——先跑 `bash preflight.sh`，有 FAIL 先修
- 启动：docker compose up -d --build
- 配对码：docker compose exec aicode cat /data/pair-code
- 详细步骤见站点上的 deploy-for-ai.md
